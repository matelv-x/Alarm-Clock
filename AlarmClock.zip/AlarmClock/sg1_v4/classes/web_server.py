do_GET — alarm

elif request_path == "/get/alarm_clock":
    data = self.stargate.alarm_clock.get_alarm_data()

elif request_path == "/get/alarm_audio_files":
    data = {
        "files": self.stargate.alarm_clock.list_audio_files()
    }

elif request_path == "/get/alarm_clock_pi_time":
    data = self.stargate.alarm_clock.get_pi_time_data()

do_POST — alarm

elif self.path == '/do/test_alarm_clock':
    data = self.stargate.alarm_clock.test_alarm(data.get('audio_file'))

elif self.path == '/do/stop_alarm_clock':
    data = self.stargate.alarm_clock.stop_alarm()

elif self.path == '/update/alarm_clock':
    try:
        alarm_data = self.stargate.alarm_clock.update_alarm(data)
        data = {
            "success": True,
            "message": "Alarm clock settings saved.",
            "alarm": alarm_data
        }
    except Exception as exc:
        data = {"success": False, "message": str(exc)}
