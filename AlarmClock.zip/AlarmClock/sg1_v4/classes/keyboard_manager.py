Alarm stop logic (inside keypress_handler)

# --- ALARM STOP ---
if key == self.center_button_key and hasattr(self.stargate, 'alarm_clock') and self.stargate.alarm_clock.is_active():
    self.log.log('Alarm stop requested from DHD center button')
    self.stargate.alarm_clock.stop_alarm()
    return